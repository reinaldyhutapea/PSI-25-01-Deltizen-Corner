<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Str;
use Yajra\Datatables\Datatables;

class ProductController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware('role:admin');
    // }

    public function index()
    {
        $title = 'Master Product';
        $products = Product::orderBy('name','asc')->get();
        $categories = Category::orderBy('name','asc')->get();
        return view('products.index', compact('title','products','categories'));
    }

    public function create()
    {
        $title = 'Create Product';
        $categories = Category::orderBy('name','asc')->get();
        return view('products.index',compact('title','categories'));
    }

   
    public function store(Request $request)
    {
   
        $input = new Product;
        $input->id=$request->id;
        $input->description=$request->description;
        $input->name=$request->name;
        $input->price=$request->price;
        $input->stock=$request->stock;
      
        if ($request->hasFile('image')){
            $input['image'] = '/upload/products/'.str::slug($input['name'], '-').'.'.$request->image->getClientOriginalExtension();
            $request->image->move(public_path('/upload/products/'), $input['image']);
        }

        $input->category_id=$request->category_id;
    
        
        $input->save();

        return redirect()->back()->with('status','Anda berhasil menambahkan product');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $title = 'Edit Product';
        $product = Product::findOrFail($id);
        $categories = Category::orderBy('name','asc')->get();
        return view('products.edit', compact('product', 'title','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $input = $request->all();
        $product = Product::findOrFail($id);  
        $input['image'] = $product->image;

        if ($request->hasFile('image')){
            if (!$product->image == NULL){
                unlink(public_path($product->image));
            }
            $input['image'] = '/upload/products/'.str::slug($input['name'], '-').'.'.$request->image->getClientOriginalExtension();
            $request->image->move(public_path('/upload/products/'), $input['image']);
        }

        $product->update($input);
        return redirect()->back()->with('status','Anda berhasil mengubah data produdct');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        if (!$product->image == NULL){
            unlink(public_path($product->image));
        }

        Product::destroy($id);
        return redirect()->back()->with('status','Anda berhasil menghapus produk'.$product->name);
    }

    public function detail($id)
    {
        $product = Product::findOrFail($id);
        return view('products.detail',compact('product'));
    }

   
   
   public function produk (){
       return view('products.index2');
   }

public function produkData (){
$data = Product::join('categories', 'products.category_id', '=', 'categories.id')
->select('products.id', 'products.name as pname', 'categories.name as cname', 'products.description',
'products.price','products.stock', 'products.image');

return Datatables::of($data)
->addColumn('action', function ($data) {
    $actiona = '<a href="'.route('product.edit',$data->id).'" class="btn btn-xs btn-primary" ><i class="fa-solid fa-pen-to-square"></i></a>';
    $actionb = '<a href="'.route('product.detail',$data->id).'" class="btn btn-xs btn-warning"><i class="fa-solid fa-circle-info"></i></a>';
    $actionc = '<a href="'.route('product.destroy',$data->id).'" class="btn btn-xs btn-danger"><i class="fa-solid fa-trash"></i></a>';
    return $actiona . $actionb . $actionc ;
})
->addIndexColumn()
->editColumn('image', function($data){
    return '<img src=" '.url($data->image).' "/>';
})
->rawColumns(['image','action'])
->make(true);
}


}
